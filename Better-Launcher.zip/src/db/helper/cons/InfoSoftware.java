package db.helper.cons;

public class InfoSoftware {
    
    public static final String SEARCH = "select * from Softwares join Infos using(softwareId)"; 
    
}
