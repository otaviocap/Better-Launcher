# Better-Launcher
A new way to launch your apps
